"""Short-only margin call strategy utilities for Bybit linear futures (interactive symbol selection)."""

from .config import TraderConfig
from .main_engine import run  # noqa: F401
