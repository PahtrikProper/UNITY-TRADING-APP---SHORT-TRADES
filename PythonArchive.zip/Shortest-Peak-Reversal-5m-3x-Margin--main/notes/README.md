# Notes directory

- `strategy_overview.md` — summary of the ChoCH/BOS workflow, components, and run commands for the four packages (BTC/SOL, live/paper) and the live short trader variant (optimizer + Bybit futures executor with isolated, limit-only Bybit orders).
- Use this directory to capture research ideas, experiment results, and follow-up investigations.
